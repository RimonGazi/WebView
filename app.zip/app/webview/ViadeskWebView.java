package com.viadesk.app.webview;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.viadesk.app.MainActivity;
import com.viadesk.app.webview.client.ViadeskWebChromeClient;
import com.viadesk.app.webview.client.ViadeskWebViewClient;
import com.viadesk.app.webview.client.handler.BrowserDownloadListener;
import com.viadesk.app.webview.client.handler.DownloadHandler;
import com.viadesk.app.webview.client.handler.UploadHandler;
import com.viadesk.app.webview.controller.ActivityController;
import com.viadesk.app.webview.controller.WebViewController;

import java.util.HashMap;
import java.util.Map;

public class ViadeskWebView extends RelativeLayout implements ActivityController, WebViewController {

    private static final String TAG = "ViadeskWebView";
    public final static int FILE_SELECTED = 112;

    private Activity activity;
    private WebView mWebView;
    private ProgressBar mProgressBar;
    private UploadHandler mUploadHandler;
    private DownloadHandler mDownloadHandler;

    public ViadeskWebView(final Context context) {
        super(context);
        init();
    }

    public ViadeskWebView(final Context context, final AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ViadeskWebView(final Context context,
                          final AttributeSet attrs, final int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public ViadeskWebView(final Context context, final AttributeSet attrs,
                          final int defStyleAttr, final int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    private void init() {
        setGravity(CENTER_VERTICAL);
        activity = (Activity) getContext();

        mWebView = new WebView(getContext());
        final RelativeLayout.LayoutParams webViewParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        webViewParams.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
        addView(mWebView, webViewParams);

        mProgressBar = new ProgressBar(getContext());
        final RelativeLayout.LayoutParams progressBarParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        progressBarParams.addRule(RelativeLayout.CENTER_IN_PARENT);
        addView(mProgressBar, progressBarParams);

        mWebView.setWebViewClient(new ViadeskWebViewClient(this));
        mWebView.setWebChromeClient(new ViadeskWebChromeClient(this));
        setWebViewSetting();
        setDownloadHandler();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setWebViewSetting() {
        final WebSettings webViewSettings = mWebView.getSettings();
        webViewSettings.setLoadsImagesAutomatically(true);
        webViewSettings.setJavaScriptEnabled(true);
        webViewSettings.setUseWideViewPort(true);
    }

    private void setDownloadHandler() {
        mDownloadHandler = new DownloadHandler(this);
        final BrowserDownloadListener mDownloadListener = new BrowserDownloadListener() {
            public void onDownloadStart(final String url, final String userAgent,
                                        final String contentDisposition, final String mimetype,
                                        final String referer, final long contentLength) {
                mDownloadHandler.onDownloadStart(activity, url,
                        userAgent, contentDisposition, mimetype, referer);
            }
        };
        mWebView.setDownloadListener(mDownloadListener);
    }

    @Override
    public void start(final Intent intent) {

    }

    @Override
    public void onSaveInstanceState(final Bundle outState) {

    }

    @Override
    public void handleNewIntent(final Intent intent) {
        if (intent != null) {
            final Uri uri = intent.getData();
            if (uri != null) {
                String a = uri.toString().replace("com.googleusercontent.apps.83604623656-2s9me98n3nttnfr1p9s5a49uqva8fd7g", MainActivity.url);
                Log.d("DDD", a);
                mWebView.loadUrl(a);
            }
        }
    }

    @Override
    public void onResume() {

    }

    @Override
    public void onPause() {

    }

    @Override
    public void onDestroy() {
        if (mUploadHandler != null && !mUploadHandler.handled()) {
            mUploadHandler.onResult(Activity.RESULT_CANCELED, null);
            mUploadHandler = null;
        }
    }

    @Override
    public void onConfgurationChanged(final Configuration newConfig) {

    }

    @Override
    public void onLowMemory() {

    }

    @Override
    public void onBackPressed() {
        if (mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            activity.finish();
        }
    }

    @Override
    public void onActionModeStarted(final ActionMode mode) {

    }

    @Override
    public void onActionModeFinished(final ActionMode mode) {

    }

    @Override
    public void onActivityResult(final int requestCode, final int resultCode, final Intent intent) {

        switch (requestCode) {
            case FILE_SELECTED:

                if (null != mUploadHandler) {
                    Log.d(TAG, "file result called ");
                    mUploadHandler.onResult(resultCode, intent);
                }
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(final int requestCode,
                                           @NonNull final String[] permissions,
                                           @NonNull final int[] grantResults) {
        if (requestCode == DownloadHandler.STORAGE_PERMISSIONS_REQUEST_TO_SAVE_DOWNLOAD_FILE) {
            if (grantResults.length == 1 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mDownloadHandler.storagePermissionGranted();
            }
        }
    }

    @Override
    public boolean hasRequestPermission(final String permission, final int requestCode) {
        final int hasPermission = ContextCompat.checkSelfPermission(getActivity(), permission);
        if (hasPermission == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                activity.requestPermissions(new String[]{permission}, requestCode);
            }
        }
        return false;
    }

    @Override
    public Activity getActivity() {
        return activity;
    }

    @Override
    public void onPageStarted(final WebView view, final String url, final Bitmap favicon) {
        updateUi(true);
    }

    @Override
    public boolean shouldOverrideUrlLoading(final WebView view, final String url) {
        Log.d("FDDDDD", "openCustomTab 0");
        if (hasOverrideUrlLoading(url)) {
            Log.d("FDDDDD", "openCustomTab 1");
            openCustomTab(url);
            return true;
        }
        return false;
    }

    @Override
    public void onProgressChanged(final WebView view, final int newProgress) {

    }

    @Override
    public void onPageFinished(final WebView view, final String url) {
        updateUi(false);
    }

    @Override
    public boolean shouldOverrideKeyEvent(final KeyEvent event) {
        return false;
    }

    @Override
    public boolean onUnhandledKeyEvent(final KeyEvent event) {
        return false;
    }

    @Override
    public void doUpdateVisitedHistory(final boolean isReload) {
    }

    @Override
    public void getVisitedHistory(final ValueCallback<String[]> callback) {

    }

    @Override
    public void onReceivedHttpAuthRequest(final WebView view, final HttpAuthHandler handler,
                                          final String host, final String realm) {
    }

    @Override
    public void showCustomView(final View view, final int requestedOrientation,
                               final WebChromeClient.CustomViewCallback callback) {
    }

    @Override
    public void hideCustomView() {

    }

    @Override
    public Bitmap getDefaultVideoPoster() {
        return null;
    }

    @Override
    public View getVideoLoadingProgressView() {
        return null;
    }

    @Override
    public void showSslCertificateOnError(final WebView view, final SslErrorHandler handler,
                                          final SslError error) {
    }

    @Override
    public boolean shouldShowErrorConsole() {
        return false;
    }

    @Override
    public void showFileChooser(final ValueCallback<Uri[]> callback,
                                final WebChromeClient.FileChooserParams params) {
        mUploadHandler = new UploadHandler(this);
        mUploadHandler.openFileChooser(callback, params);
    }

    @Override
    public void endActionMode() {

    }

    @Override
    public boolean shouldCaptureThumbnails() {
        return false;
    }

    private boolean hasOverrideUrlLoading(final String uri) {
        final String googleLoginUri = "https://login.microsoftonline.com";
        //final String googleLoginUri = "https://accounts.google.com/o/oauth2/v2/auth?client_id";
        // + "=403370678988-fjf485np01bihb78gmd4sntd602ge751.apps";
        return uri.contains(googleLoginUri);
    }

    private void openCustomTab(final String uri) {
//        final CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
//        final CustomTabsIntent customTabsIntent = builder.build();
//        final CustomTabPackage customTabPackage = new CustomTabPackage();
//        customTabsIntent.intent.setPackage(customTabPackage.getPackageNameToUse(getContext()));
//        customTabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
//        customTabsIntent.launchUrl(activity, Uri.parse(uri));
        Log.d("FDDDDD", "openCustomTab");
        final MainActivity activity = (MainActivity) getActivity();
        activity.signIn();
    }

    public void loadUrl(final String url) {
        mWebView.loadUrl(url);
    }

    public void loadUrl(final String url, String idToken) {
        final Map<String, String> additionalHttpHeaders = new HashMap<>();
        additionalHttpHeaders.put("Authorization", "Bearer " + idToken);
        mWebView.loadUrl(url, additionalHttpHeaders);
    }

    private void updateUi(final boolean loadingUlr) {
        if (loadingUlr) {
            mWebView.setVisibility(INVISIBLE);
            mProgressBar.setVisibility(VISIBLE);
        } else {
            mWebView.setVisibility(VISIBLE);
            mProgressBar.setVisibility(INVISIBLE);
        }
    }
}
