package com.viadesk.app.webview.controller;


import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public interface WebViewController {

    boolean hasRequestPermission(final String permission, final int requestCode);

    Context getContext();

    Activity getActivity();

    void onPageStarted(final WebView view, final String url, final Bitmap favicon);

    boolean shouldOverrideUrlLoading(final WebView view, final String url);

    void onProgressChanged(WebView view, int newProgress);

    void onPageFinished(final WebView view, final String url);

    boolean shouldOverrideKeyEvent(final KeyEvent event);

    boolean onUnhandledKeyEvent(final KeyEvent event);

    void doUpdateVisitedHistory(final boolean isReload);

    void getVisitedHistory(final ValueCallback<String[]> callback);

    void onReceivedHttpAuthRequest(final WebView view, final HttpAuthHandler handler,
                                   final String host, final String realm);

    void showCustomView(View view, int requestedOrientation,
                        WebChromeClient.CustomViewCallback callback);

    void hideCustomView();

    Bitmap getDefaultVideoPoster();

    View getVideoLoadingProgressView();

    void showSslCertificateOnError(final WebView view,
                                   final SslErrorHandler handler, final SslError error);

    boolean shouldShowErrorConsole();

    void showFileChooser(final ValueCallback<Uri[]> callback,
                         final WebChromeClient.FileChooserParams params);

    void endActionMode();

    boolean shouldCaptureThumbnails();
}

