package com.viadesk.app.webview.client;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.os.Build;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.viadesk.app.webview.controller.WebViewController;

public class ViadeskWebViewClient extends WebViewClient {

    private final WebViewController webViewController;

    public ViadeskWebViewClient(final WebViewController webViewController) {
        this.webViewController = webViewController;
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean shouldOverrideUrlLoading(final WebView view, final String url) {
        return webViewController.shouldOverrideUrlLoading(view, url);
    }

    @TargetApi(Build.VERSION_CODES.N)
    @Override
    public boolean shouldOverrideUrlLoading(final WebView view, final WebResourceRequest request) {
        final String url = request.getUrl().toString();
        return webViewController.shouldOverrideUrlLoading(view, url);
    }

    @Override
    public void onPageStarted(final WebView view, final String url, final Bitmap favicon) {
        super.onPageStarted(view, url, favicon);
        webViewController.onPageStarted(view, url, favicon);
    }

    @Override
    public void onPageFinished(final WebView view, final String url) {
        super.onPageFinished(view, url);
        webViewController.onPageFinished(view, url);
    }
}
