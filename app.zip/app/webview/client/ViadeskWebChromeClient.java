package com.viadesk.app.webview.client;

import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import com.viadesk.app.webview.controller.WebViewController;


public class ViadeskWebChromeClient extends WebChromeClient {

    private final WebViewController webViewController;

    public ViadeskWebChromeClient(final WebViewController webViewController) {
        this.webViewController = webViewController;
    }

    @Override
    public void onProgressChanged(final WebView view, final int newProgress) {
        super.onProgressChanged(view, newProgress);
        webViewController.onProgressChanged(view, newProgress);
    }

    @Override
    public boolean onShowFileChooser(final WebView webView,
                                     final ValueCallback<Uri[]> filePathCallback,
                                     final FileChooserParams fileChooserParams) {
        webViewController.showFileChooser(filePathCallback, fileChooserParams);
        return true;
    }
}
