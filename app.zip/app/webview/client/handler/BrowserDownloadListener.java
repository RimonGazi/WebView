/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.viadesk.app.webview.client.handler;

import android.webkit.DownloadListener;

/**
 * An abstract download listener that allows passing extra information as
 * part of onDownloadStart callback.
 */
public abstract class BrowserDownloadListener implements DownloadListener {

    /**
     * Notify the host application that a file should be downloaded
     * @param url The full url to the content that should be downloaded
     * @param userAgent the user agent to be used for the download.
     * @param contentDisposition Content-disposition http header, if
     *                           present.
     * @param mimetype The mimetype of the content reported by the server
     * @param referer The referer associated with this url
     * @param contentLength The file size reported by the server
     */
    public abstract void onDownloadStart(String url, String userAgent, String contentDisposition,
                                         String mimetype, String referer, long contentLength);

    /**
     * Notify the host application that a file should be downloaded
     * @param url The full url to the content that should be downloaded
     * @param userAgent the user agent to be used for the download.
     * @param contentDisposition Content-disposition http header, if
     *                           present.
     * @param mimetype The mimetype of the content reported by the server
     * @param contentLength The file size reported by the server
     */
    @Override
    public void onDownloadStart(final String url, final String userAgent,
                                final String contentDisposition,
                                final String mimetype, final long contentLength) {

        onDownloadStart(url, userAgent, contentDisposition, mimetype, null, contentLength);
    }
}
