/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.viadesk.app.webview.client.handler;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.widget.Toast;

import com.viadesk.app.R;
import com.viadesk.app.webview.ViadeskWebView;
import com.viadesk.app.webview.controller.WebViewController;

import java.io.File;

/**
 * Handle the file upload. This does not support selecting multiple files yet.
 */
public class UploadHandler {

    private final static String IMAGE_MIME_TYPE = "image/*";
    private final static String VIDEO_MIME_TYPE = "video/*";
    private final static String AUDIO_MIME_TYPE = "audio/*";
    private final static String FILE_PROVIDER_AUTHORITY = "com.viadesk.app-classic.file";

    /*
     * The Object used to inform the WebView of the file to upload.
     */
    private ValueCallback<Uri[]> mUploadMessage;

    private boolean mHandled;
    private final WebViewController mController;
    private FileChooserParams mParams;
    private Uri mCapturedMedia;

    public UploadHandler(final WebViewController controller) {
        mController = controller;
    }

    public boolean handled() {
        return mHandled;
    }

    public void onResult(final int resultCode, final Intent intent) {
        final Uri[] uris;
        uris = parseResult(resultCode, intent);
        if (uris != null && uris.length > 0) {
            mUploadMessage.onReceiveValue(uris);
        }
        mHandled = true;
    }

    @SuppressLint("Assert")
    public void openFileChooser(final ValueCallback<Uri[]> callback, final FileChooserParams fileChooserParams) {

        if (mUploadMessage != null) {
            // Already a file picker operation in progress.
            return;
        }
        mUploadMessage = callback;
        mParams = fileChooserParams;
        final Intent[] captureIntents = createCaptureIntent();
        assert (captureIntents != null && captureIntents.length > 0);
        final Intent intent;
        // Go to the media capture directly if capture is specified, this is the
        // preferred way.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (fileChooserParams.isCaptureEnabled()
                    && captureIntents.length == 1) {
                intent = captureIntents[0];
            } else {
                intent = new Intent(Intent.ACTION_CHOOSER);
                intent.putExtra(Intent.EXTRA_INITIAL_INTENTS, captureIntents);
                intent.putExtra(Intent.EXTRA_INTENT, fileChooserParams.createIntent());
            }
        } else {

            final Intent chooserIntent = new Intent(Intent.ACTION_GET_CONTENT);
            chooserIntent.addCategory(Intent.CATEGORY_OPENABLE);
            chooserIntent.setType("*/*");
            intent = Intent.createChooser(chooserIntent, null);
        }
        startActivity(intent);
    }

    private Uri[] parseResult(final int resultCode, final Intent intent) {
        Uri[] uris = null;
        if (resultCode == Activity.RESULT_OK && intent != null) {
            Uri result = intent.getData();
            if ((result == null) && mCapturedMedia != null) {
                result = mCapturedMedia;
            }
            if (result != null) {
                uris = new Uri[1];
                uris[0] = result;
            }
        }
        return uris;
    }

    private void startActivity(final Intent intent) {
        try {
            mController.getActivity().startActivityForResult(intent, ViadeskWebView.FILE_SELECTED);
        } catch (final ActivityNotFoundException e) {
            // No installed app was able to handle the intent that
            // we sent, so file upload is effectively disabled.
            Toast.makeText(mController.getActivity(), R.string.uploads_disabled,
                    Toast.LENGTH_LONG).show();
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private Intent[] createCaptureIntent() {
        String mimeType = "*/*";
        final String[] acceptTypes = mParams.getAcceptTypes();
        if (acceptTypes != null && acceptTypes.length > 0) {
            mimeType = acceptTypes[0];
        }
        final Intent[] intents;
        switch (mimeType) {
            case IMAGE_MIME_TYPE:
                intents = new Intent[1];
                intents[0] = createCameraIntent(createTempFileContentUri(".jpg"));
                break;
            case VIDEO_MIME_TYPE:
                intents = new Intent[1];
                intents[0] = createCamcorderIntent();
                break;
            case AUDIO_MIME_TYPE:
                intents = new Intent[1];
                intents[0] = createSoundRecorderIntent();
                break;
            default:
                intents = new Intent[3];
                intents[0] = createCameraIntent(createTempFileContentUri(".jpg"));
                intents[1] = createCamcorderIntent();
                intents[2] = createSoundRecorderIntent();
                break;
        }
        return intents;
    }

    private Uri createTempFileContentUri(final String suffix) {
        try {
            final File filesDir = mController.getActivity().getFilesDir();
            final File mediaPath = new File(filesDir, "captured_media");
            if (!mediaPath.exists() && !mediaPath.mkdir()) {
                throw new RuntimeException("Folder cannot be created.");
            }
            final File mediaFile = File.createTempFile(
                    String.valueOf(System.currentTimeMillis()), suffix, mediaPath);
            return FileProvider.getUriForFile(mController.getActivity(),
                    FILE_PROVIDER_AUTHORITY, mediaFile);
        } catch (final java.io.IOException e) {
            throw new RuntimeException(e);
        }
    }

    private Intent createCameraIntent(final Uri contentUri) {
        if (contentUri == null) throw new IllegalArgumentException();
        mCapturedMedia = contentUri;
        final Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, mCapturedMedia);
        final ContentResolver contentResolver = mController.getActivity().getContentResolver();
        intent.setClipData(ClipData.newUri(contentResolver,
                FILE_PROVIDER_AUTHORITY, mCapturedMedia));
        return intent;
    }

    private Intent createCamcorderIntent() {
        return new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
    }

    private Intent createSoundRecorderIntent() {
        return new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION);
    }
}
