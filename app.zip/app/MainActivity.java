package com.viadesk.app;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.viadesk.app.webview.ViadeskWebView;

import net.openid.appauth.AuthState;
import net.openid.appauth.AuthorizationException;
import net.openid.appauth.AuthorizationRequest;
import net.openid.appauth.AuthorizationResponse;
import net.openid.appauth.AuthorizationService;
import net.openid.appauth.AuthorizationServiceConfiguration;
import net.openid.appauth.TokenResponse;

public class MainActivity extends AppCompatActivity implements
        GoogleApiClient.OnConnectionFailedListener {
    //private static final String AUTHORITY = "https://login.microsoftonline.com/simonj.onmicrosoft.com";
    private ViadeskWebView webView;
   // public static final String url = "http://192.168.255.180:8080";
    public static final String url = "https://gijs.viadesk.com";
    private static final String USED_INTENT = "USED_INTENT";
    private static final int RC_SIGN_IN = 9001;
    String TAG = "MainActivity";

    private GoogleApiClient mGoogleApiClient;

    //AuthenticationContext authenticationContext;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = (ViadeskWebView) findViewById(R.id.web_view);
        webView.loadUrl(url);

        final GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestIdToken("266743652197-oi6nb46jjm0d6e0rap2p96r64q4kph40.apps.googleusercontent.com")
                .build();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
    }

//    @Override
//    public void onStart() {
//        super.onStart();
//        OptionalPendingResult<GoogleSignInResult> opr = Auth.GoogleSignInApi.silentSignIn(mGoogleApiClient);
//        if (opr.isDone()) {
//            Log.d(TAG, "Got cached sign-in");
//            GoogleSignInResult result = opr.get();
//            handleSignInResult(result);
//        } else {
//            opr.setResultCallback(new ResultCallback<GoogleSignInResult>() {
//                @Override
//                public void onResult(GoogleSignInResult googleSignInResult) {
//                    handleSignInResult(googleSignInResult);
//                }
//            });
//        }
//    }

    @Override
    protected void onNewIntent(final Intent intent) {
        //webView.handleNewIntent(intent);
        Log.d(TAG, "1called");
        checkIntent(intent);
    }

    private void checkIntent(@Nullable Intent intent) {
        if (intent != null) {
            String action = intent.getAction();
            switch (action) {
                case "com.vaidesk.appauth.HANDLE_AUTHORIZATION_RESPONSE":
                    Log.d(TAG, "called");
                    if (!intent.hasExtra(USED_INTENT)) {
                        handleAuthorizationResponse(intent);
                        intent.putExtra(USED_INTENT, true);
                    }
                    break;
                default:
                    // do nothing
            }
        }
    }

    private void handleAuthorizationResponse(@NonNull Intent intent) {
        AuthorizationResponse response = AuthorizationResponse.fromIntent(intent);
        AuthorizationException error = AuthorizationException.fromIntent(intent);
        final AuthState authState = new AuthState(response, error);

        if (response != null) {
            Log.i(TAG, String.format("Handled Authorization Response %s ", authState.toJsonString()));
            AuthorizationService service = new AuthorizationService(this);
            service.performTokenRequest(response.createTokenExchangeRequest(),
                    new AuthorizationService.TokenResponseCallback() {
                        @Override
                        public void onTokenRequestCompleted(@Nullable TokenResponse tokenResponse,
                                                            @Nullable AuthorizationException exception) {
                            if (exception != null) {
                                Log.w(TAG, "Token Exchange failed", exception);
                            } else {
                                if (tokenResponse != null) {
                                    authState.update(tokenResponse, exception);
                                    // persistAuthState(authState);
                                    Log.i(TAG, String.format("Token Response [ Access Token: %s, ID Token: %s ]",
                                            tokenResponse.accessToken, tokenResponse.idToken));
                                    Log.i(TAG, "id token " + tokenResponse.idToken);
                                    webView.loadUrl(url + "/do/googleauthenticate", tokenResponse.idToken);
                                }
                            }
                        }
                    });
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onSaveInstanceState(final Bundle outState) {
        webView.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        webView.onDestroy();
    }

    @Override
    public void onConfigurationChanged(final Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        webView.onConfgurationChanged(newConfig);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        webView.onLowMemory();
    }

    @Override
    public void onBackPressed() {
        webView.onBackPressed();
    }

    @Override
    public boolean onKeyDown(final int keyCode, final KeyEvent event) {
        return webView.onKeyDown(keyCode, event) ||
                super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyLongPress(final int keyCode, final KeyEvent event) {
        return webView.onKeyLongPress(keyCode, event) ||
                super.onKeyLongPress(keyCode, event);
    }

    @Override
    public boolean onKeyUp(final int keyCode, final KeyEvent event) {
        return webView.onKeyUp(keyCode, event) ||
                super.onKeyUp(keyCode, event);
    }

    @Override
    public void onActionModeStarted(final ActionMode mode) {
        super.onActionModeStarted(mode);
        webView.onActionModeStarted(mode);
    }

    @Override
    public void onActionModeFinished(final ActionMode mode) {
        super.onActionModeFinished(mode);
        webView.onActionModeFinished(mode);
    }

    @Override
    protected void onActivityResult(final int requestCode,
                                    final int resultCode, final Intent intent) {

        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(intent);
            handleSignInResult(result);
        } else {
//            if (authenticationContext != null) {
//                authenticationContext.onActivityResult(requestCode, resultCode, intent);
//            }
            webView.onActivityResult(requestCode, resultCode, intent);
        }
    }

    @Override
    public void onRequestPermissionsResult(final int requestCode,
                                           @NonNull final String[] permissions,
                                           @NonNull final int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        webView.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public boolean dispatchKeyEvent(final KeyEvent event) {
        return webView.dispatchKeyEvent(event)
                || super.dispatchKeyEvent(event);
    }

    @Override
    public boolean dispatchKeyShortcutEvent(final KeyEvent event) {
        return webView.dispatchKeyShortcutEvent(event)
                || super.dispatchKeyShortcutEvent(event);
    }

    @Override
    public boolean dispatchTouchEvent(final MotionEvent ev) {
        return webView.dispatchTouchEvent(ev)
                || super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean dispatchTrackballEvent(final MotionEvent ev) {
        return webView.dispatchTrackballEvent(ev)
                || super.dispatchTrackballEvent(ev);
    }

    @Override
    public boolean dispatchGenericMotionEvent(final MotionEvent ev) {
        return webView.dispatchGenericMotionEvent(ev) ||
                super.dispatchGenericMotionEvent(ev);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    private void updateUI(boolean b) {
    }

    public void signIn() {
        Log.d("FDDDDD", "signIN");
        AuthorizationServiceConfiguration serviceConfiguration = new AuthorizationServiceConfiguration(
                Uri.parse("https://login.microsoftonline.com/common/oauth2/v2.0/authorize") /* auth endpoint */,
                Uri.parse("https://login.microsoftonline.com/common/oauth2/v2.0/token") /* token endpoint */
        );

        String clientId = getString(R.string.ms_app_id);
        //Uri redirectUri = Uri.parse("msalca19e9c0-f9db-45c9-a3ca-d1221cac6ba7://auth");
     Uri redirectUri = Uri.parse("  ://auth");
        AuthorizationRequest.Builder builder = new AuthorizationRequest.Builder(
                serviceConfiguration,
                clientId,
                AuthorizationRequest.RESPONSE_TYPE_CODE,
                redirectUri
        );
        String scope[] = new String[]{
                // An example set of scopes your application could use
                "openid",
                "https://graph.microsoft.com/User.Read"
//              "email"
        };

        //"https://graph.microsoft.com/User.Read"
        builder.setScopes(scope);
//        builder.setsetLoginHint("jdoe@user.example.com");
        AuthorizationRequest request = builder.build();

        AuthorizationService authorizationService = new AuthorizationService(this);

        String action = "com.vaidesk.appauth.HANDLE_AUTHORIZATION_RESPONSE";
        Intent postAuthorizationIntent = new Intent(action);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, request.hashCode(), postAuthorizationIntent, 0);
        authorizationService.performAuthorizationRequest(request, pendingIntent);
//
//        String GRAPH_RESOURCE = "https://graph.microsoft.com";
//        String REDIRECT_URI = "https://MicrosoftGraph.iOS.Objective-C.SendMail/";
//        authenticationContext = new AuthenticationContext(MainActivity.this, AUTHORITY, true);
//        authenticationContext.acquireToken(MainActivity.this, GRAPH_RESOURCE, getString(R.string.ms_app_id), REDIRECT_URI, PromptBehavior.Auto,
//                new AuthenticationCallback<AuthenticationResult>() {
//                    @Override
//                    public void onSuccess(AuthenticationResult result) {
//                        Log.d(TAG, "onSuccess ,  token :  " + result.getIdToken());
//
//                    }
//
//                    @Override
//                    public void onError(Exception exc) {
//                        Log.d(TAG, "onError" + exc.getMessage());
//                    }
//                });

//        final IAuthenticationAdapter authenticationAdapter = new MSAAuthAndroidAdapter(getApplication()) {
//            @Override
//            public String getClientId() {
//                return getString(R.string.ms_app_id);
//            }
//
//            @Override
//            public String[] getScopes() {
//                return new String[]{
//                        "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
//                        "https://login.microsoftonline.com/common/oauth2/v2.0/token",
//                        "https://graph.microsoft.com/Calendars.ReadWrite",
//                        "https://graph.microsoft.com/Contacts.ReadWrite",
//                        "https://graph.microsoft.com/Files.ReadWrite",
//                        "https://graph.microsoft.com/Mail.ReadWrite",
//                        "https://graph.microsoft.com/Mail.Send",
//                        "https://graph.microsoft.com/User.ReadBasic.All",
//                        "https://graph.microsoft.com/User.ReadWrite",
//                        "offline_access",
//                        "openid"
//                };
//            }
//        };
//
//        authenticationAdapter.login(this, new ICallback<Void>() {
//            @Override
//            public void success(Void aVoid) {
//                final IClientConfig mCLientConfig = DefaultClientConfig
//                        .createWithAuthenticationProvider(authenticationAdapter);
//
//                final IGraphServiceClient mClient = new GraphServiceClient
//                        .Builder()
//                        .fromConfig(mCLientConfig)
//                        .buildClient();
//            }
//
//            @Override
//            public void failure(ClientException ex) {
//
//            }
//        });

        // This will use SharedPreferences as            default cache
//        final Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
//        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    // [END signIn]

    // [START signOut]
    private void signOut() {
        Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
                        // [START_EXCLUDE]
                        updateUI(false);
                        // [END_EXCLUDE]
                    }
                });
    }

    private void handleSignInResult(final GoogleSignInResult result) {
        Log.d(TAG, "handleSignInResult:" + result.isSuccess());
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();
            Log.d(TAG, "handleSignInResult:" + acct.getIdToken());
            webView.loadUrl(url + "/do/googleauthenticate", acct.getIdToken());
        } else {
            // Signed out, show unauthenticated UI.
            updateUI(false);
        }
    }
}
